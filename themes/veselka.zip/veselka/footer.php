<div class="site-section py-5 bg-warning">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12 d-flex">
          <h2 class="text-white m-0">Подарить детям веселую жизнь</h2>
          <a href="/контакты/" class="btn btn-primary btn-custom-1 py-3 px-5 ml-auto">Записаться</a>
          </div>
        </div>
      </div>
    </div>



    <footer class="site-footer">
      <div class="container">
        <div class="row pt-5 text-center">
          <div class="col-md-12">
            <div>
              <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | All rights reserved | Этот сайт разработан <a href="https://www.facebook.com/stetsenko.freelance" target="_blank" ><i class="icon-heart text-danger" aria-hidden="true"></i> Andrew Stetsenko</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>

        </div>
      </div>
    </footer>

    </div>

<?php wp_footer(); ?>
<script>(function($,d){$.each(readyQ,function(i,f){$(f)});$.each(bindReadyQ,function(i,f){$(d).bind("ready",f)})})(jQuery,document)</script>
  </body>

</html>
